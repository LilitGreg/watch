<?php get_header(); ?>
<div class="clearfix container-fluid">
    <div class="row">

    </div>
</div>
<?php get_footer(); ?>
